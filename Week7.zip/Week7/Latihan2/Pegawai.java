package Latihan2;
import java.util.Scanner;

class Karyawan
{
    String nama_karyawan;
    int tunjangan_anak = 3000000;
    int jumlah_hari_masuk;
    int total_upah;
    int total_gaji;

        // Method Menginputkan Nama
        public void input_nama()
        {
            Scanner nama = new Scanner(System.in);

            System.out.print("Masukan Nama Karyawan = ");
            nama_karyawan = nama.nextLine();
            
            System.out.println("Nama Karyawan = " + nama_karyawan);
        }
}

class KaryawanTetap extends Karyawan
{
    int gaji_pokok = 10000000;

        // Method Menampilkan Total Gaji
        public void karyawan_tetap()
        {
            input_nama();
            Scanner nama = new Scanner(System.in);

            Scanner tetap = new Scanner(System.in);

            total_gaji = gaji_pokok + tunjangan_anak;
            System.out.println("Gaji Anda Sebesar = " + total_gaji);
        }

        public void Karyawan_Kontrak() {
        }
}

class KaryawanKontrak extends Karyawan
{
    int upah_harian = 335000;

        // Method Menampilkan Total Upah
        public void karyawan_kontrak()
        {
            input_nama();
            Scanner nama = new Scanner(System.in);
            
            Scanner kontrak = new Scanner(System.in);

            System.out.print("Masukan Jumlah Hari Masuk = ");       
            jumlah_hari_masuk = kontrak.nextInt();

            total_upah = upah_harian * jumlah_hari_masuk + tunjangan_anak;
            System.out.println("Total Upah Yang Diterima Sebesar = " + total_upah); 

        }
}

public class Pegawai
{
    public static void main(String[] args)
    {
        int pilihan;
        int ulang;

        do
        {

        Scanner utama = new Scanner(System.in);

        KaryawanTetap T = new KaryawanTetap();
        KaryawanKontrak K = new KaryawanKontrak();

        System.out.println("[1] Karyawan Tetap");
        System.out.println("[2] Karyawan Kontrak");
        System.out.println("==================================== \n");
        System.out.print("Pilih Golongan Anda = ");
        pilihan = utama.nextInt();

        if(pilihan == 1)
        {
            T.karyawan_tetap();
        }

        else if(pilihan == 2)
        {
            K.karyawan_kontrak();
        }

        else
        {
                System.out.println("Data Golongan Tidak Tersedia");
        }

            System.out.println("[1] Lanjut");
            System.out.println("[2] Tidak Lanjut");
            System.out.print("Apakah Anda Ingin Mengulang Program = ");
            ulang = utama.nextInt();
            System.out.println("");

        }while(ulang == 1);
        System.out.println("Terima Kasih");

    }
    
}


